<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'includes/db.php';

// Check if user is admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user || !$user['is_admin']) {
    header("Location: dashboard.php");
    exit();
}

$query = "SELECT id, name, email, subject, message, submitted_at FROM contact_messages ORDER BY submitted_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Manage Contact Messages</title>
<style>
  /* Reset some basics */
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #fff8f0;
    color: #4a4a4a;
    margin: 0;
    padding: 30px 20px;
  }

  h1 {
    color: #ef6c00; /* bright orange */
    text-align: center;
    margin-bottom: 30px;
    font-weight: 700;
    font-size: 2.5rem;
  }

  table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    box-shadow: 0 4px 8px rgba(239, 108, 0, 0.15);
    border-radius: 12px;
    overflow: hidden;
    background-color: #ffffff;
  }

  thead tr {
    background: #ef6c00;
    color: white;
  }

  thead th {
    padding: 15px 20px;
    text-align: left;
    font-weight: 600;
    font-size: 1rem;
    border-right: 1px solid rgba(255,255,255,0.3);
  }

  thead th:last-child {
    border-right: none;
  }

  tbody tr:nth-child(even) {
    background-color: #fff3e0; /* light orange background on even rows */
  }

  tbody tr:hover {
    background-color: #ffe0b2;
    cursor: pointer;
  }

  tbody td {
    padding: 15px 20px;
    border-right: 1px solid #f0f0f0;
    vertical-align: top;
  }

  tbody td:last-child {
    border-right: none;
  }

  a {
    color: #ef6c00;
    text-decoration: none;
    font-weight: 600;
  }

  a:hover {
    text-decoration: underline;
  }

  p {
    text-align: center;
    font-size: 1.1rem;
    color: #b35c00;
    font-weight: 600;
  }

  /* Responsive */
  @media (max-width: 768px) {
    table, thead, tbody, th, td, tr {
      display: block;
    }
    thead tr {
      display: none;
    }
    tbody tr {
      margin-bottom: 20px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(239, 108, 0, 0.1);
      padding: 15px;
    }
    tbody td {
      border: none;
      padding: 10px 15px;
      position: relative;
      padding-left: 50%;
    }
    tbody td:before {
      position: absolute;
      top: 10px;
      left: 15px;
      width: 45%;
      white-space: nowrap;
      font-weight: 700;
      color: #ef6c00;
      content: attr(data-label);
    }
  }
</style>
</head>
<body>
  <h1>Contact Messages</h1>
  <?php if ($result && $result->num_rows > 0): ?>
    <table>
      <thead>
        <tr>
          <th>Name</th><th>Email</th><th>Subject</th><th>Message</th><th>Submitted At</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td data-label="Name"><?= htmlspecialchars($row['name']) ?></td>
            <td data-label="Email"><a href="mailto:<?= htmlspecialchars($row['email']) ?>"><?= htmlspecialchars($row['email']) ?></a></td>
            <td data-label="Subject"><?= htmlspecialchars($row['subject']) ?></td>
            <td data-label="Message"><?= nl2br(htmlspecialchars($row['message'])) ?></td>
            <td data-label="Submitted At"><?= htmlspecialchars($row['submitted_at']) ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p>No messages found.</p>
  <?php endif; ?>
</body>
</html>
