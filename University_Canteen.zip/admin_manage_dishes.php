<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
require 'includes/db.php';

$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
if (!$user || !$user['is_admin']) {
    echo "Access denied.";
    exit();
}

if (isset($_POST['add_dish'])) {
    $name = $_POST['name'];
    $category = $_POST['category'];
    $tag = $_POST['tag'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $ingredients = $_POST['ingredients'];

    // Remove image handling completely
    $stmt = $conn->prepare("INSERT INTO dishes (name, category, tag, price, description, ingredients) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $category, $tag, $price, $description, $ingredients);
    $stmt->execute();
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM dishes WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

if (isset($_POST['update_dish'])) {
    $id = $_POST['dish_id'];
    $name = $_POST['name'];
    $category = $_POST['category'];
    $tag = $_POST['tag'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $ingredients = $_POST['ingredients'];

    $stmt = $conn->prepare("UPDATE dishes SET name=?, category=?, tag=?, price=?, description=?, ingredients=? WHERE id=?");
    $stmt->bind_param("ssssssi", $name, $category, $tag, $price, $description, $ingredients, $id);
    $stmt->execute();
}

$dishes = $conn->query("SELECT * FROM dishes");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Dishes</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            color: #333;
        }
        header {
            background-color: #ff6f00;
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h2 {
            margin: 0;
        }
        header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
        main {
            padding: 40px;
            max-width: 1200px;
            margin: auto;
        }
        h3 {
            color: #ff6f00;
        }
        form {
            background: #fff8f1;
            padding: 25px;
            border: 1px solid #ffc107;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        input[type="text"], textarea, input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }
        button {
            padding: 10px 20px;
            background-color: #ff6f00;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }
        button:hover {
            background-color: #e65100;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 40px;
            background-color: #fffdf8;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }
        th {
            background-color: #ffe0b2;
        }
        .actions a {
            color: #ff6f00;
            margin-right: 10px;
            text-decoration: none;
        }
        .actions a:hover {
            text-decoration: underline;
        }
        .edit-form {
            background-color: #fff3e0;
            padding: 20px;
            margin-top: 10px;
            border-left: 4px solid #ff9800;
        }
    </style>
</head>
<body>

<header>
    <h2>Manage Dishes</h2>
    <a href="bothuser_dashpage.php">← Back to Dashboard</a>
</header>

<main>

<!-- Add New Dish -->
<form method="POST">
    <h3>Add New Dish</h3>
    <input type="text" name="name" placeholder="Dish Name" required>
    <input type="text" name="category" placeholder="Category" required>
    <input type="text" name="tag" placeholder="Tag" required>
    <input type="number" step="0.01" name="price" placeholder="Price" required>
    <textarea name="description" placeholder="Description" required></textarea>
    <textarea name="ingredients" placeholder="Ingredients" required></textarea>
    <button type="submit" name="add_dish">Add Dish</button>
</form>

<!-- List Dishes -->
<table>
    <thead>
        <tr>
            <th>Name</th><th>Category</th><th>Tag</th><th>Price</th><th>Description</th><th>Ingredients</th><th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while($row = $dishes->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['category']) ?></td>
                <td><?= htmlspecialchars($row['tag']) ?></td>
                <td>₹<?= htmlspecialchars($row['price']) ?></td>
                <td><?= htmlspecialchars($row['description']) ?></td>
                <td><?= htmlspecialchars($row['ingredients']) ?></td>
                <td class="actions">
                    <a href="?edit=<?= $row['id'] ?>">Edit</a> |
                    <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this dish?')">Delete</a>
                </td>
            </tr>

            <?php if (isset($_GET['edit']) && $_GET['edit'] == $row['id']): ?>
            <tr>
                <td colspan="7">
                    <div class="edit-form">
                        <form method="POST">
                            <input type="hidden" name="dish_id" value="<?= $row['id'] ?>">
                            <input type="text" name="name" value="<?= htmlspecialchars($row['name']) ?>" required>
                            <input type="text" name="category" value="<?= htmlspecialchars($row['category']) ?>" required>
                            <input type="text" name="tag" value="<?= htmlspecialchars($row['tag']) ?>" required>
                            <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($row['price']) ?>" required>
                            <textarea name="description" required><?= htmlspecialchars($row['description']) ?></textarea>
                            <textarea name="ingredients" required><?= htmlspecialchars($row['ingredients']) ?></textarea>
                            <button type="submit" name="update_dish">Update Dish</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endif; ?>

        <?php endwhile; ?>
    </tbody>
</table>

</main>

</body>
</html>
