<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'includes/db.php';

// Check if user is admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user || !$user['is_admin']) {
    // Not admin, redirect
    header("Location: dashboard.php");
    exit();
}

// Handle delete review
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt_del = $conn->prepare("DELETE FROM reviews WHERE id = ?");
    $stmt_del->bind_param("i", $delete_id);
    $stmt_del->execute();
    $stmt_del->close();
    header("Location: manage_reviews.php");
    exit();
}

// Handle add review form submission
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_review'])) {
    $user_id = intval($_POST['user_id']);
    $dish_id = intval($_POST['dish_id']);
    $rating = intval($_POST['rating']);
    $review_text = trim($_POST['review_text']);

    // Validate input
    if ($user_id <= 0) $errors[] = "Please select a valid user.";
    if ($dish_id <= 0) $errors[] = "Please select a valid dish.";
    if ($rating < 1 || $rating > 5) $errors[] = "Rating must be between 1 and 5.";
    if (empty($review_text)) $errors[] = "Review text cannot be empty.";

    if (empty($errors)) {
        $stmt_add = $conn->prepare("INSERT INTO reviews (user_id, dish_id, rating, review_text, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt_add->bind_param("iiis", $user_id, $dish_id, $rating, $review_text);
        $stmt_add->execute();
        $stmt_add->close();
        header("Location: manage_reviews.php");
        exit();
    }
}

// Fetch all reviews with user and dish names
$sql = "SELECT r.id, r.rating, r.review_text, r.created_at, u.full_name, d.name AS dish_name
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        JOIN dishes d ON r.dish_id = d.id
        ORDER BY r.created_at DESC";
$result = $conn->query($sql);

// Fetch users for dropdown
$users_res = $conn->query("SELECT id, full_name FROM users ORDER BY full_name ASC");

// Fetch dishes for dropdown
$dishes_res = $conn->query("SELECT id, name FROM dishes ORDER BY name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Manage Reviews</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background: #f9f9f9;
      color: #333;
    }
    h1 {
      color: #ef6c00;
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
      background: #fff;
      box-shadow: 0 0 5px rgba(0,0,0,0.1);
    }
    th, td {
      padding: 12px 15px;
      border: 1px solid #ddd;
      text-align: left;
    }
    th {
      background: #ffe0b2;
      color: #ef6c00;
    }
    tr:hover {
      background: #fffbf2;
    }
    form {
      background: #fff;
      padding: 20px;
      max-width: 600px;
      box-shadow: 0 0 5px rgba(0,0,0,0.1);
      border-radius: 8px;
    }
    label {
      display: block;
      margin-bottom: 6px;
      font-weight: 600;
      color: #ef6c00;
    }
    select, textarea, input[type="number"] {
      width: 100%;
      padding: 8px 10px;
      margin-bottom: 15px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 14px;
    }
    textarea {
      resize: vertical;
      min-height: 80px;
    }
    button {
      background: #ef6c00;
      color: white;
      border: none;
      padding: 12px 20px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease;
    }
    button:hover {
      background: #d65c00;
    }
    .error {
      color: #b00000;
      margin-bottom: 15px;
      font-weight: 600;
    }
    .delete-btn {
      color: #b00000;
      text-decoration: none;
      font-weight: bold;
    }
    .delete-btn:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <h1>Manage Reviews</h1>

  <!-- Reviews Table -->
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>User</th>
        <th>Dish</th>
        <th>Rating</th>
        <th>Review</th>
        <th>Created At</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($result && $result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['full_name']) ?></td>
            <td><?= htmlspecialchars($row['dish_name']) ?></td>
            <td><?= htmlspecialchars($row['rating']) ?>/5</td>
            <td><?= nl2br(htmlspecialchars($row['review_text'])) ?></td>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
            <td>
              <a class="delete-btn" href="manage_reviews.php?delete_id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this review?');">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="7" style="text-align:center;">No reviews found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- Add Review Form -->
  <h2>Add New Review</h2>

  <?php if (!empty($errors)): ?>
    <div class="error">
      <?php foreach ($errors as $error): ?>
        <div><?= htmlspecialchars($error) ?></div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="manage_reviews.php">
    <label for="user_id">User:</label>
    <select name="user_id" id="user_id" required>
      <option value="">-- Select User --</option>
      <?php while ($user_row = $users_res->fetch_assoc()): ?>
        <option value="<?= $user_row['id'] ?>"><?= htmlspecialchars($user_row['full_name']) ?></option>
      <?php endwhile; ?>
    </select>

    <label for="dish_id">Dish:</label>
    <select name="dish_id" id="dish_id" required>
      <option value="">-- Select Dish --</option>
      <?php while ($dish_row = $dishes_res->fetch_assoc()): ?>
        <option value="<?= $dish_row['id'] ?>"><?= htmlspecialchars($dish_row['name']) ?></option>
      <?php endwhile; ?>
    </select>

    <label for="rating">Rating (1 to 5):</label>
    <input type="number" name="rating" id="rating" min="1" max="5" required />

    <label for="review_text">Review Text:</label>
    <textarea name="review_text" id="review_text" required></textarea>

    <button type="submit" name="add_review">Add Review</button>
  </form>
</body>
</html>
