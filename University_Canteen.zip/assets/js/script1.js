function toggleForm() {
  const form = document.getElementById("auth-form");
  const titleText = document.getElementById("form-text");
  const signupFields = document.getElementById("signup-fields");
  const toggleMsg = document.getElementById("toggle-msg");
  const submitButton = form.querySelector('button[type="submit"]');

  if (titleText.innerText.includes("Login")) {
    titleText.innerText = "Canteen Sign Up";
    form.action = "signup.php";
    signupFields.style.display = "block";
    submitButton.innerText = "Sign Up";          // <-- Change button text here
    toggleMsg.innerHTML = 'Already have an account? <a href="#" onclick="toggleForm()">Login</a>';
  } else {
    titleText.innerText = "Canteen Login";
    form.action = "login.php";
    signupFields.style.display = "none";
    submitButton.innerText = "Login";            // <-- Change button text here
    toggleMsg.innerHTML = 'Don\'t have an account? <a href="#" onclick="toggleForm()">Sign up</a>';
  }
}
