<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'includes/db.php'; // Use same path as homepage

$stmt = $conn->prepare("SELECT full_name, is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    session_destroy();
    header("Location: index.php");
    exit();
}

$full_name = htmlspecialchars($user['full_name']);
$is_admin = $user['is_admin'];

// Fetch total users count if admin
$total_users = 0;
if ($is_admin) {
    $stmt_count = $conn->prepare("SELECT COUNT(*) as user_count FROM users");
    $stmt_count->execute();
    $result_count = $stmt_count->get_result();
    if ($row = $result_count->fetch_assoc()) {
        $total_users = $row['user_count'];
    }
    $stmt_count->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background-color: #ffffff;
      color: #333;
      position: relative;
      min-height: 100vh;
      padding-bottom: 60px; /* space for fixed back button */
    }

    /* New logout button styles */
    .logout-button {
      position: fixed;
      top: 20px;
      right: 20px;
      background-color: #ef6c00;
      color: white;
      border: none;
      padding: 10px 18px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.3s ease;
      text-decoration: none;
      font-size: 14px;
      z-index: 1000;
    }

    .logout-button:hover {
      background-color: #d35400;
    }

    .sidebar {
      position: fixed;
      width: 240px;
      height: 100vh;
      background: #fff3e0;
      border-right: 1px solid #ffd9b3;
      padding: 30px 20px;
      box-shadow: 4px 0 10px rgba(0, 0, 0, 0.04);
    }

    .sidebar h2 {
      color: #ef6c00;
      font-size: 22px;
      margin-bottom: 40px;
      font-weight: 700;
    }

    .sidebar ul {
      list-style: none;
    }

    .sidebar ul li {
      margin-bottom: 16px;
    }

    .sidebar ul li a {
      display: block;
      padding: 10px 16px;
      border-radius: 10px;
      text-decoration: none;
      color: #444;
      font-weight: 500;
      transition: 0.3s ease;
    }

    .sidebar ul li a:hover {
      background: #ffe0b2;
      color: #ef6c00;
    }

    .main {
      margin-left: 260px;
      padding: 40px 50px;
      background-color: #ffffff;
      min-height: 100vh;
    }

    .dashboard-title {
      font-size: 30px;
      color: #ef6c00;
      margin-bottom: 25px;
      font-weight: 600;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 24px;
    }

    .card {
      background: linear-gradient(135deg, #ffe0b2,rgb(255, 128, 221));
      padding: 25px;
      border-radius: 20px;
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.06);
      transition: 0.3s ease;
      color: #2c2c2c;
    }

    .card:hover {
      transform: translateY(-6px);
      box-shadow: 0 10px 24px rgba(0, 0, 0, 0.1);
    }

    .card h3 {
      font-size: 22px;
      font-weight: 600;
      color: #ef6c00;
      margin-bottom: 10px;
    }

    .card p {
      font-size: 14px;
      color: #444;
    }

    /* New styles for graph card */
    .card.graph {
      position: relative;
      padding-bottom: 50px; /* extra space for the graph */
    }

    .graph-bar-container {
      width: 100%;
      height: 20px;
      background: #ffe0b2;
      border-radius: 10px;
      overflow: hidden;
      margin-top: 15px;
      box-shadow: inset 0 2px 5px rgba(0,0,0,0.1);
    }

    .graph-bar {
      height: 100%;
      background: linear-gradient(90deg, #ff8c00, #ff64aa);
      width: 0%;
      border-radius: 10px 0 0 10px;
      transition: width 1.2s ease;
    }

    .graph-label {
      position: absolute;
      bottom: 10px;
      right: 20px;
      font-size: 12px;
      color: #333;
      font-weight: 600;
    }

    /* Back button fixed at bottom left */
    .back-button {
      position: fixed;
      bottom: 20px;
      left: 20px;
      background-color: #add8e6; /* light blue */
      color: #000;
      border: none;
      padding: 10px 18px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.3s ease;
      box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }

    .back-button:hover {
      background-color: #87ceeb; /* darker light blue */
    }
  </style>
</head>
<body>
  <a href="dashboard_logout.php" class="logout-button">Logout</a>

  <div class="sidebar">
    <h2>Dashboard</h2>
    <ul>
      <li><a href="profile.php">Profile</a></li>
      <li><a href="settings.php">Settings</a></li>
      <?php if ($is_admin): ?>
        <li><a href="admin_manage_reviews.php">Manage Reviews</a></li>
        <li><a href="admin_manage_contacts.php">Manage Contacts</a></li>
        <li><a href="admin_manage_dishes.php">Manage Dishes</a></li>
      <?php else: ?>
        <li><a href="user_manage_reviews.php">Manage My Reviews</a></li>
      <?php endif; ?>
    </ul>
  </div>

  <div class="main">
    <div class="dashboard-title">Welcome Back, <?= $full_name ?>!</div>
    <div class="grid">
      <?php if ($is_admin): ?>
        <div class="card graph">
          <h3>Total Users</h3>
          <p><?= htmlspecialchars($total_users) ?> users</p>
          <div class="graph-bar-container">
            <div id="graphBar" class="graph-bar"></div>
          </div>
          <div class="graph-label">Users count</div>
        </div>

        <a href="admin_manage_reviews.php" class="card" style="display: block; text-decoration: none; color: inherit;">
          <h3>Reviews</h3>
          <p>View all user feedback and comments.</p>
        </a>

        <a href="admin_manage_contacts.php" class="card" style="display: block; text-decoration: none; color: inherit;">
          <h3>Messages</h3>
          <p>Check your latest messages here.</p>
        </a>

        <a href="admin_manage_dishes.php" class="card" style="display: block; text-decoration: none; color: inherit;">
          <h3>Manage Dishes</h3>
          <p>Update, add, or remove dishes from the menu.</p>
        </a>

      <?php else: ?>

        <a href="user_manage_reviews.php" class="card" style="display: block; text-decoration: none; color: inherit;">
          <h3>My Reviews</h3>
          <p>See the reviews you've submitted.</p>
        </a>

      <?php endif; ?>
    </div>
  </div>

  <button class="back-button" onclick="window.location.href='homepage1.php'">Back</button>

  <script>
    // Animate the bar width based on total users, capped at 100 for visualization
    document.addEventListener("DOMContentLoaded", () => {
      const totalUsers = <?= (int)$total_users ?>;
      const maxUsers = 100; // max for graph bar width
      const graphBar = document.getElementById('graphBar');
      if (graphBar) {
        const widthPercent = totalUsers > maxUsers ? 100 : (totalUsers / maxUsers) * 100;
        graphBar.style.width = widthPercent + '%';
      }
    });
  </script>
</body>
</html>
