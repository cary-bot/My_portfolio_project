<?php
$reviews = file_exists("reviews_chicken_biryani.txt") ? file("reviews_chicken_biryani.txt", FILE_IGNORE_NEW_LINES) : [];

$totalRating = 0;
$reviewCount = 0;

foreach ($reviews as $line) {
    $parts = explode("|", $line, 2); // limit to 2 parts
    if (count($parts) === 2) {
        list($rating, $comment) = $parts;
        $totalRating += (int)$rating;
        $reviewCount++;
    }
}

$averageRating = $reviewCount > 0 ? round($totalRating / $reviewCount, 1) : "No ratings yet";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>University Canteen - Chicken Biryani</title>
  <link rel="stylesheet" href="maindish_nonveg_styles.css">
</head>
<body>

<div class="container">
  <!-- Image -->
  <div class="image-container">
    <img src="chicken_biryani.jpg" alt="Chicken Biryani">
  </div>

  <!-- Product Details -->
  <div class="product-details">
    <div class="breadcrumbs">
      <a href="#">Home</a> > <a href="#">Canteen</a> > Chicken Biryani
    </div>

    <h1>
      Chicken Biryani
      <span class="nonveg-icon" title="Non-Vegetarian"></span>
    </h1>

    <div class="price">₹150</div>

    <div class="rating">
      <strong>Average Rating:</strong>
      <?php if ($averageRating !== "No ratings yet") { ?>
        ★ <?php echo $averageRating; ?> / 5
      <?php } else { ?>
        <span>No ratings yet</span>
      <?php } ?>
    </div>

    <div class="description">
      <h3>Description:</h3>
      <p>A flavorful and aromatic rice dish made with tender chicken, spices, and basmati rice. Served with raita and a boiled egg on the side. A must-try for all biryani lovers!</p>
    </div>

    <div class="ingredients">
      <h3>Ingredients:</h3>
      <ul>
        <li>Chicken</li>
        <li>Basmati Rice</li>
        <li>Onions, Tomatoes, Garlic, Ginger</li>
        <li>Garam Masala, Turmeric, Red Chili</li>
        <li>Coriander & Mint</li>
        <li>Yogurt, Salt, Oil</li>
      </ul>
    </div>

    <!-- Review Form -->
    <div class="review-section">
      <h3>Rate & Review</h3>
      <form action="submit_review_chicken_biryani.php" method="post">
        <label for="rating">Rating (1-5):</label>
        <input type="number" name="rating" id="rating" min="1" max="5" required>
        <label for="review">Review:</label>
        <textarea name="review" id="review" rows="3" placeholder="Share your thoughts..." required></textarea>
        <button type="submit">Submit Review</button>
      </form>

      <div class="reviews-list">
        <h3>Customer Reviews</h3>
        <?php
        if ($reviewCount === 0) {
            echo "<p class='no-reviews'>No reviews yet.</p>";
        } else {
            foreach (array_reverse($reviews) as $r) {
                $parts = explode("|", $r, 2);
                if (count($parts) === 2) {
                    list($rating, $comment) = $parts;
                    echo "<div class='review-box'>
                            <p><strong>Rating:</strong> " . htmlspecialchars($rating) . "/5</p>
                            <p><strong>Comment:</strong> " . htmlspecialchars($comment) . "</p>
                          </div>";
                }
            }
        }
        ?>
      </div>
    </div>
  </div>
</div>

</body>
</html>
