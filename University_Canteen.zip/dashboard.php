<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'includes/db.php'; // Make sure this path is correct

// Fetch full_name from DB
$stmt = $conn->prepare("SELECT full_name FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    // User not found, log out
    session_destroy();
    header("Location: index.php");
    exit();
}

$full_name = $user['full_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Canteen Dashboard</title>
  <link rel="stylesheet" href="landing_page_style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
  <section class="hero">
   <div class="hero-content">
    <img src="adbu.jpg" alt="UniLogo" style="max-width: 150px; height: auto; margin-bottom: 20px;">
  </a>
  <h1>Welcome, <?= htmlspecialchars($full_name); ?>!</h1>
  <p>"Your one-stop destination to explore what's on the Uni canteen menu today, rate your food, leave reviews, and more!"</p>
  <a href="homepage1.php" class="btn">Explore Now</a>
</div>

  </section>
</body>
</html>
