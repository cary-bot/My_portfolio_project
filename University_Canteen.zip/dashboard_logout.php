<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Canteen Dashboard</title>
  <link rel="stylesheet" href="landing_page_style.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
  <section class="hero">
    <div class="hero-content">
     <h1> Thank You!</h1>
      <p>"You've been logged out."</p>
      <a href="homepage.php" class="btn"> Go back to Homepage </a>
    </div>
  </section>
</body>
</html>
