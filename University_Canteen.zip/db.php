<?php
$host = "localhost:4306";
$user = "Kerlarity";
$pass = "@Kerla2121";
$db = "canteen_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>         