<?php
session_start();
require 'includes/db.php';

// Get dish id from URL
if (!isset($_GET['dish_id']) || !is_numeric($_GET['dish_id'])) {
    die("Dish ID is invalid or missing.");
}

$dish_id = (int)$_GET['dish_id'];

// Fetch dish info
$stmt = $conn->prepare("SELECT * FROM dishes WHERE id = ?");
$stmt->bind_param("i", $dish_id);
$stmt->execute();
$dish_result = $stmt->get_result();

if ($dish_result->num_rows === 0) {
    die("Dish not found.");
}
$dish = $dish_result->fetch_assoc();

// Fetch reviews for this dish
$reviews_stmt = $conn->prepare("
    SELECT users.full_name, reviews.review_text, reviews.rating, reviews.created_at
    FROM reviews
    JOIN users ON reviews.user_id = users.id
    WHERE reviews.dish_id = ?
    ORDER BY reviews.created_at DESC
");
$reviews_stmt->bind_param("i", $dish_id);
$reviews_stmt->execute();
$reviews_result = $reviews_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>University Canteen - <?= htmlspecialchars($dish['name']) ?></title>
  <link rel="stylesheet" href="maindish_styles.css" />
  <style>
    .veg-symbol, .non-veg-symbol {
      display: inline-block;
      width: 16px;
      height: 16px;
      border: 2px solid;
      position: relative;
      vertical-align: middle;
      margin-left: 8px;
      border-radius: 2px;
      background-color: white;
    }
    .veg-symbol {
      border-color: #008000;
    }
    .veg-symbol::after {
      content: "";
      position: absolute;
      top: 50%;
      left: 50%;
      width: 8px;
      height: 8px;
      background-color: #008000;
      border-radius: 50%;
      transform: translate(-50%, -50%);
    }
    .non-veg-symbol {
      border-color: #A52A2A;
    }
    .non-veg-symbol::after {
      content: "";
      position: absolute;
      top: 50%;
      left: 50%;
      width: 8px;
      height: 8px;
      background-color: #A52A2A;
      border-radius: 50%;
      transform: translate(-50%, -50%);
    }

    .back-button {
      display: inline-block;
      padding: 8px 16px;
      background-color: #5dade2;
      color: white;
      text-decoration: none;
      font-weight: 600;
      border-radius: 4px;
      transition: background-color 0.3s ease;
      box-shadow: 0 2px 5px rgba(0,0,0,0.15);
      user-select: none;
    }

    .back-button:hover,
    .back-button:focus {
      background-color: #2e86c1;
      outline: none;
    }

    .review-section {
      margin-top: 30px;
    }

    .review textarea {
      width: 100%;
    }

    .reviews-list {
      margin-top: 20px;
    }

    .review {
      padding: 10px;
      background-color: #f5f5f5;
      border-radius: 5px;
      margin-bottom: 15px;
    }
  </style>
</head>
<body>

<div class="container">

  <div class="image-container">
    <?php if (!empty($dish['image_path'])): ?>
      <img src="<?= htmlspecialchars($dish['image_path']) ?>" alt="<?= htmlspecialchars($dish['name']) ?>" />
    <?php else: ?>
      <img src="default_dish_img.jpg" alt="No Image" />
    <?php endif; ?>
  </div>

  <div class="product-details">
    <div class="breadcrumbs">
      <a href="index.php">Home</a> &gt; <a href="menu.php">Canteen</a> &gt; <?= htmlspecialchars($dish['name']) ?>
    </div>

    <h1>
      <?= htmlspecialchars($dish['name']) ?>
      <?php if ($dish['tag'] === 'veg'): ?>
          <span class="veg-symbol" title="Vegetarian"></span>
      <?php elseif ($dish['tag'] === 'non-veg'): ?>
          <span class="non-veg-symbol" title="Non-Vegetarian"></span>
      <?php else: ?>
          <span class="no-tag-icon" title="No tag specified">❓</span>
      <?php endif; ?>
    </h1>

    <p><strong>Category:</strong> <?= htmlspecialchars($dish['category']) ?></p>

    <div class="price">₹<?= htmlspecialchars($dish['price']) ?></div>

    <div class="description">
      <h3>Description:</h3>
      <p><?= nl2br(htmlspecialchars($dish['description'] ?? 'No description available.')) ?></p>
    </div>

    <div class="ingredients">
      <h3>Ingredients:</h3>
      <?php if (!empty($dish['ingredients'])): ?>
        <ul>
          <?php
          $normalized = str_replace(',', "\n", $dish['ingredients']);
          $ingredients = preg_split('/\r\n|\r|\n/', $normalized);
          foreach ($ingredients as $ing) {
              $trimmed = trim($ing);
              if ($trimmed !== '') {
                  echo "<li>" . htmlspecialchars($trimmed) . "</li>";
              }
          }
          ?>
        </ul>
      <?php else: ?>
        <p>No ingredients listed.</p>
      <?php endif; ?>
    </div>

    <!-- Review Form -->
    <div class="review-section">
      <h3>Rate & Review</h3>

      <form action="submit_review.php" method="post" id="reviewForm">
        <input type="hidden" name="dish_id" value="<?= $dish_id ?>" />
        <label for="rating">Rating (1-5):</label>
        <input type="number" name="rating" id="rating" min="1" max="5" required />
        <label for="review">Review:</label>
        <textarea name="review" id="review" rows="3" placeholder="Share your thoughts..." required></textarea>
        <button type="submit">Submit Review</button>
      </form>

      <?php if (!isset($_SESSION['user_id'])): ?>
      <script>
      document.getElementById('reviewForm').addEventListener('submit', function(e) {
          e.preventDefault(); // prevent actual submission
          if (confirm("You need to log in to submit a review. Do you want to go to the login page?")) {
              window.location.href = 'index.html'; // redirect to login
          }
          // else do nothing
      });
      </script>
      <?php endif; ?>

      <div class="reviews-list">
        <h3>Customer Reviews</h3>
        <?php if ($reviews_result->num_rows === 0): ?>
            <p>No reviews yet. Be the first!</p>
        <?php else: ?>
            <?php while ($review = $reviews_result->fetch_assoc()): ?>
                <div class="review">
                    <p><strong><?= htmlspecialchars($review['full_name']) ?>:</strong> 
                    (Rating: <?= (int)$review['rating'] ?>/5)</p>
                    <p><?= nl2br(htmlspecialchars($review['review_text'])) ?></p>
                    <small>🕒 <?= htmlspecialchars($review['created_at']) ?></small>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
      </div>
    </div>

    <p><a href="menu.php" class="back-button">⬅ Back to Menu</a></p>
  </div>

</div>

</body>
</html>
