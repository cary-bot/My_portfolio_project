<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'includes/db.php';  // Adjust path if needed

$stmt = $conn->prepare("SELECT full_name FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    session_destroy();
    header("Location: index.php");
    exit();
}

$full_name = htmlspecialchars($user['full_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>University Canteen</title>
  <link rel="stylesheet" href="homepage_styles.css" />
  <style>
    .profile-menu {
      position: relative;
      display: inline-block;
    }

    .profile-btn {
      background: none;
      border: none;
      cursor: pointer;
      font-size: 16px;
      color: rgb(235, 202, 39);
      padding: 5px 10px;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 5px;
    }

    .profile-btn:focus {
      outline: none;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      right: 0;
      background-color: #fff;
      min-width: 140px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      border-radius: 5px;
      overflow: hidden;
      z-index: 1000;
    }

    .dropdown-content a {
      color: #333;
      padding: 10px 15px;
      text-decoration: none;
      display: block;
      font-weight: 500;
      transition: background-color 0.2s ease;
    }

    .dropdown-content a:hover {
      background-color: #f0f0f0;
    }

    .profile-menu.open .dropdown-content {
      display: block;
    }
/* Menu Highlight Section and Filter Buttons Integration */

/* Match dynamic dishes section styles with quick-nav */

.dynamic-dishes-section {
  margin: 2rem 1rem;  /* same margin as quick-nav */
}
.filter-btn {
  background-color: #db712b; /* same orange as quick-nav .tile */
  padding: 1rem;             /* same padding */
  border-radius: 10px;       /* same border-radius */
  text-align: center;        /* center text */
  width: auto;               /* let width be based on content */
  min-width: 120px;          /* slightly bigger min width for consistency */
  max-width: 180px;          /* restrict max width to keep buttons smaller */
  cursor: pointer;
  font-weight: bold;
  font-size: 1.2rem;         /* same font size */
  color: white;
  border: none;
  transition: transform 0.2s ease;
  white-space: nowrap;       /* prevent text wrapping */
  display: inline-block;     /* inline block for sizing */
}

.filter-buttons {
  display: flex;
  justify-content: center;   /* center all buttons */
  gap: 1.5rem;
  flex-wrap: wrap;
  margin-bottom: 1rem;
}

.filter-btn:hover {
  transform: scale(1.05);    /* same hover scale effect */
  background-color: #db712b; /* keep same bg color on hover (optional) */
}

.filter-btn.active {
  transform: scale(1.05);    /* keep active scale effect */
  background-color:rgb(224, 218, 32); /* darker shade for active (optional) */
  color: white;
}

.card-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 1.5rem; /* slightly smaller gap to visually align better with tiles */
}

.photo-gallery {
  background-color: #f9f9f9;
  padding: 1rem 0; /* Reduced from 3rem to 1rem */
  width: 100vw;
  position: relative;
  left: 50%;
  right: 50%;
  margin-left: -50vw;
  margin-right: -50vw;
}

.gallery-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  justify-content: center;
}
    
  </style>
</head>
<body>
  <header class="navbar">
    <div class="logo">
      <img src="adbu.jpg" alt="UniLogo" style="height: 50px; vertical-align: middle; margin-right: 8px;">
      UniCanteen
    </div>
    <nav>
      <a href="homepage1.php">Home</a>
      <a href="menu_today.html">Today-Specials</a>
      <a href="regular_menu.html">Regular Menu</a>
      <a href="menu.php">Rate & Review</a>
      <a href="contact.html">Contact</a>
    </nav>

    <div class="actions profile-menu">
      <button class="profile-btn" aria-haspopup="true" aria-expanded="false" aria-label="User profile menu">
        Welcome! <?= $full_name ?> ▼
      </button>
      <div class="dropdown-content" role="menu" aria-label="Profile menu">
        <a href="profile.php" role="menuitem">Profile</a>
        <a href="settings.php" role="menuitem">Settings</a>
        <a href="bothuser_dashpage.php" role="menuitem">Visit Dashboard</a>
        <a href="logout.php" role="menuitem">Logout</a>
      </div>
    </div>
  </header>

  <section class="welcome-banner">
     <h1>Welcome to Assam Don Bosco University Canteen </h1>
    <p>Explore. Rate. Review.</p>
  </section>

  <section class="daily-specials">
  <h2>Today’s Timed Specials</h2>
</section>

<section class="dynamic-dishes-section">
  <div class="filter-buttons">
    <button class="filter-btn active" data-filter="all">Show All</button>
    <button class="filter-btn" data-filter="breakfast">Breakfast</button>
    <button class="filter-btn" data-filter="lunch">Lunch</button>
    <button class="filter-btn" data-filter="snacks">Snacks</button>
  </div>
  <div class="card-container" id="dynamic-dishes-container">
    <!-- Cards will be dynamically inserted here -->
  </div>
</section>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const dishes = [
      {
        id: 1,
        img: 'spicy_paneer_wrap.jpg',
        title: 'Spicy Paneer Wrap',
        desc: 'A flavorful wrap with marinated paneer and fresh veggies.',
        tags: ['vegetarian', 'spicy', 'wrap', 'snacks', 'today-special'],
        price: '₹70',
        link: 'spicy_paneer_wrap.html',
      },
      {
        id: 2,
        img: 'aloo_paratha.jpeg',
        title: 'Aloo Paratha',
        desc: 'Flatbread stuffed with spiced potatoes, served with yogurt.',
        tags: ['vegetarian', 'northindian', 'breakfast', 'today-special'],
        price: '₹40',
        link: 'aloo_paratha.html',
      },
      {
        id: 3,
        img: 'fruit_salad.jpeg',
        title: 'Fruit Salad',
        desc: 'Fresh fruits with honey and nuts.',
        tags: ['healthy', 'dessert', 'snacks', 'today-special'],
        price: '₹40',
        link: 'fruit_salad.html',
      },
      {
        id: 4,
        img: 'rajme_chawal.jpeg',
        title: 'Rajma Chawal',
        desc: 'Classic North Indian dish with kidney beans curry and rice.',
        tags: ['vegetarian', 'northindian', 'lunch', 'today-special'],
        price: '₹80',
        link: 'rajma_chawal.html',
      }
    ];

    function getCurrentMealTag() {
      const hour = new Date().getHours();
      if (hour >= 8 && hour < 11) return 'breakfast';
      if (hour >= 11 && hour < 15) return 'lunch';
      return 'snacks';
    }

    const container = document.getElementById('dynamic-dishes-container');
    const buttons = document.querySelectorAll('.filter-btn');

    function setActiveButton(filter) {
      buttons.forEach(btn => {
        if (btn.dataset.filter === filter) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });
    }

    function renderCards(filter, ignoreTimeCheck = false) {
      container.innerHTML = '';
      let filteredDishes;

      if (filter === 'all') {
        filteredDishes = dishes;
      } else if (filter === 'today-special') {
        filteredDishes = dishes.filter(d => d.tags.includes('today-special'));
      } else if (['breakfast', 'lunch', 'snacks'].includes(filter)) {
        if (ignoreTimeCheck) {
          filteredDishes = dishes.filter(d => d.tags.includes(filter));
        } else {
          const currentMeal = getCurrentMealTag();
          if (currentMeal !== filter) {
            container.innerHTML = `<p>Sorry, it's not ${filter} time right now. Please check other options.</p>`;
            return false;
          }
          filteredDishes = dishes.filter(d => d.tags.includes(filter));
        }
      } else {
        filteredDishes = dishes.filter(d => d.tags.includes(filter));
      }

      if (filteredDishes.length === 0) {
        container.innerHTML = '<p>No dishes available for this category currently.</p>';
        return true;
      }

      filteredDishes.forEach(dish => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
          <img src="${dish.img}" alt="${dish.title}" />
          <h3>${dish.title}</h3>
          <p>${dish.desc}</p>
          <p class="tags">${dish.tags.map(tag => '#' + tag).join(' ')}</p>
          <p class="price">${dish.price}</p>
          <a href="${dish.link}" class="details-btn">Details</a>
        `;
        container.appendChild(card);
      });

      return true;
    }

    // Initial load logic
    const initialFilter = getCurrentMealTag();
    const shown = renderCards(initialFilter);
    if (shown) {
      setActiveButton(initialFilter);
    } else {
      renderCards('all');
      setActiveButton('all');
    }

    // Button click event
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const selectedFilter = btn.dataset.filter;
        setActiveButton(selectedFilter);
        renderCards(selectedFilter, true);
      });
    });
  });
</script>


  <section class="menu-standard">
    <h2>Explore the Regular Menu</h2>
    <div class="card-container">
      <div class="card">
        <img src="masala_dosa.jpg" alt="Standard Dish 1" />
        <h3>Masala Dosa</h3>
        <p>South Indian delight with chutney and sambar.</p>
        <p class="tags">#vegetarian #southindian</p>
        <p class="price">₹50</p>
        <a href="masala_dosa.html" class="details-btn">Details</a>
      </div>
      <div class="card">
        <img src="veg_thali.jpg" alt="Standard Dish 2" />
        <h3>Veg Thali</h3>
        <p>Meal with curry, rice, dal, roti, and dessert.</p>
        <p class="tags">#veg #combo #thali</p>
        <p class="price">₹90</p>
        <a href="veg_thali.html" class="details-btn">Details</a>
      </div>
      <div class="card">
        <img src="pasta.jpeg" alt="Standard Dish 3" />
        <h3>Pasta</h3>
        <p>Italian-style spicy pasta made in-house.</p>
        <p class="tags">#continental #vegetarian</p>
        <p class="price">₹80</p>
        <a href="pasta.html" class="details-btn">Details</a>
      </div>
    </div>
    <a href="regular_menu.html" class="more-category-btn">More in this Category</a>

   
    <section class="photo-gallery">
  <!-- Photo Gallery Preview -->
    <div class="photo-gallery">
      <h3>Gallery Preview</h3>
      <div class="thumbnails">
        <img src="image.jpg" alt="Gallery 1">
        <img src="Img10.jpg" alt="Gallery 2">
        <img src="Img11.jpg" alt="Gallery 3">
        <img src="Img12.jpg" alt="Gallery 4">
      </div>
    </div>
</section>


    <div class="contact-hours">
      <h3>Contact & Canteen Hours</h3>
      <p><strong>Email:</strong> canteen@university.edu</p>
      <p><strong>Phone:</strong> +91-9876543210</p>
      <p><strong>Hours:</strong> Mon–Sat: 8 AM – 4 PM | Sun: Closed</p>
    </div>
  </section>

  <footer class="footer">
    <p>&copy; 2025 University Canteen</p>
    <div class="footer-links">
      <a href="/policies">Policies</a>
      <a href="/feedback">Feedback</a>
      <a href="/contact">Contact</a>
    </div>
  </footer>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const profileMenu = document.querySelector('.profile-menu');
      const profileBtn = document.querySelector('.profile-btn');
      const dropdown = profileMenu.querySelector('.dropdown-content');

      profileBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = profileMenu.classList.toggle('open');
        profileBtn.setAttribute('aria-expanded', isOpen);
      });

      // Prevent clicks inside dropdown from closing it
      dropdown.addEventListener('click', (e) => {
        e.stopPropagation();
      });

      // Close on outside click
      document.addEventListener('click', () => {
        profileMenu.classList.remove('open');
        profileBtn.setAttribute('aria-expanded', false);
      });
    });
  </script>
</body>
</html>
