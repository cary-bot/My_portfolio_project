<?php
$host = "localhost:4306";
$user = "root";
$pass = "";
$db = "canteen_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4 for better Unicode support
$conn->set_charset("utf8mb4");
?>
