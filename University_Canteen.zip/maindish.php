
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>University Canteen - Veg Biryani</title>
  <link rel="stylesheet" href="maindish_styles.css">
  <style>
    .review-section {
  padding: 10px;
  text-align: left; 
  background-color: inherit;
}

.review-container {
  display: flex;
  justify-content: flex-star; 
  align-items: center;
}

.review-container .btn-box {
  background: #ff8000; 
  padding: 14px 32px;
  font-size: 18px;
  border-radius: 40px;
  color: white;
  text-decoration: none;
  font-weight: 600;
  transition: box-shadow 0.3s ease;
  cursor: pointer; 
}

.review-container .btn-box:hover {
  box-shadow: 0 0 10px #ffaa33, 0 0 20px #ffaa33, 0 0 40px #ffaa33;
}
    </style>
</head>
<body>

<div class="container">
  <!-- Image -->
  <div class="image-container">
    <img src="maindish_img.jpg" alt="Veg Biryani">
  </div>

  <!-- Product Details -->
  <div class="product-details">
    <div class="breadcrumbs">
      <a href="#">Home</a> > <a href="#">Canteen</a> > Veg Biryani
    </div>

    <h1>
      Veg Biryani
      <span class="veg-icon" title="Vegetarian"></span>
    </h1>

    <div class="price">₹70</div>

    <div class="description">
      <h3>Description:</h3>
      <p>Aromatic basmati rice cooked with mixed vegetables, spices, and herbs. Our Veg Biryani is flavorful, filling, and made fresh daily in the canteen kitchen.</p>
    </div>

    <div class="ingredients">
      <h3>Ingredients:</h3>
      <ul>
        <li>Basmati Rice</li>
        <li>Seasonal Vegetables</li>
        <li>Ginger-Garlic Paste</li>
        <li>Spices & Herbs</li>
        <li>Mint, Coriander</li>
        <li>Curd, Salt, Oil</li>
      </ul>
    </div>

    <!-- Review Form -->
    <section class="review-section">
  <div class="review-container">
    <a href="rate_and_review.php" class="btn-box">Write a Review</a>
  </div>
</section>

  </div>
</div>

</body>
</html>


