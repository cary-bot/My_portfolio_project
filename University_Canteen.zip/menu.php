<?php
session_start();
require 'includes/db.php';

$user = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT full_name, username, email FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

$menu_query = "SELECT * FROM dishes ORDER BY category, name";
$result = $conn->query($menu_query);

$current_category = '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Menu - University Canteen</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      background-color: #fff;
      color: #333;
    }

    /* New Navbar */
    header.navbar {
      background: #2c3e50;
      color: #fff;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 2rem;
      position: sticky;
      top: 0;
      z-index: 100;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      font-family: 'Georgia', serif;
    }
    header.navbar .logo {
      font-size: 1.8rem;
      font-weight: bold;
      letter-spacing: 2px;
    }
    header.navbar nav a {
      color: white;
      text-decoration: none;
      margin-left: 1.5rem;
      font-weight: 600;
      transition: color 0.3s ease;
    }
    header.navbar nav a:hover {
      color: #ffd180;
    }
    header.navbar .user-info {
      font-weight: 600;
      font-size: 1rem;
    }
    header.navbar .user-info a {
      color: #ffd180;
      margin-left: 1rem;
      text-decoration: none;
      font-weight: 600;
    }
    header.navbar .user-info a:hover {
      text-decoration: underline;
    }

    /* Footer */
    footer.footer {
      text-align: center;
      margin-top: 3rem;
      padding: 1.5rem 0;
      background: #c04e01;
      color: white;
      font-size: 1rem;
      font-family: 'Georgia', serif;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    footer.footer a {
      color: #ffd180;
      margin: 0 0.8rem;
      text-decoration: none;
      font-weight: 600;
    }
    footer.footer a:hover {
      text-decoration: underline;
    }

    /* Menu Container */
    .container {
      max-width: 1000px;
      margin: 50px auto;
      padding: 40px;
      background: rgba(255, 153, 51, 0.1);
      border-radius: 20px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    h1 {
      text-align: center;
      color: #ff9933;
      font-size: 42px;
      margin-bottom: 40px;
    }

    h2 {
      margin-top: 40px;
      font-size: 28px;
      color: #ffa94d;
      border-bottom: 2px solid #ff9933;
      padding-bottom: 8px;
    }

    ul {
      list-style: none;
      padding-left: 0;
    }

    li {
      padding: 15px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #ccc;
      color: #333;
    }

    .dish-left {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .dish-name {
      font-size: 18px;
      font-weight: 500;
      color: #333;
    }

    .btn-review {
      background-color: #ff6600;
      color: white;
      padding: 8px 16px;
      border: none;
      border-radius: 20px;
      font-weight: 600;
      cursor: pointer;
      text-decoration: none;
      transition: background-color 0.3s, box-shadow 0.3s;
    }

    .btn-review:hover {
      background-color: #ff9933;
      box-shadow: 0 0 10px #ffa94d, 0 0 20px #ffcc99;
    }

    .price {
      color: #333;
      font-size: 18px;
      font-weight: bold;
      margin-right: 20px;
    }

    .veg-symbol, .non-veg-symbol {
      display: inline-block;
      width: 16px;
      height: 16px;
      border: 2px solid;
      position: relative;
      vertical-align: middle;
      border-radius: 2px;
      background-color: white;
    }

    .veg-symbol {
      border-color: #008000;
    }

    .veg-symbol::after {
      content: "";
      position: absolute;
      top: 50%;
      left: 50%;
      width: 8px;
      height: 8px;
      background-color: #008000;
      border-radius: 50%;
      transform: translate(-50%, -50%);
    }

    .non-veg-symbol {
      border-color: #A52A2A;
    }

    .non-veg-symbol::after {
      content: "";
      position: absolute;
      top: 50%;
      left: 50%;
      width: 8px;
      height: 8px;
      background-color: #A52A2A;
      border-radius: 50%;
      transform: translate(-50%, -50%);
    }
  </style>
</head>
<body>

<!-- Navbar -->
<header class="navbar">
  <div class="logo">
      <img src="adbu.jpg" alt="UniLogo" style="height: 50px; vertical-align: middle; margin-right: 8px;">
      UniCanteen
    </div>
  <nav>
    <a href="homepage1.php">Home</a>
    <a href="menu_today.html">Today-Specials</a>
    <a href="regular_menu.html">Regular Menu</a>
    <a href="rate_and_review.php" aria-current="page">Rate & Review</a>
    <a href="contact.html">Contact</a>
  </nav>

 
</header>

<!-- Menu Container -->
<div class="container">
  <h1> Rate & Review </h1>
  <?php
  while ($dish = $result->fetch_assoc()) {
      if ($dish['category'] !== $current_category) {
          if ($current_category !== '') {
              echo "</ul>";
          }
          $current_category = $dish['category'];
          echo "<h2>" . htmlspecialchars($current_category) . "</h2><ul>";
      }

      $icon_html = '';
      if ($dish['tag'] === 'veg') {
          $icon_html = '<span class="veg-symbol" title="Vegetarian"></span>';
      } elseif ($dish['tag'] === 'non-veg') {
          $icon_html = '<span class="non-veg-symbol" title="Non-Vegetarian"></span>';
      } else {
          $icon_html = '<span title="No tag specified">❓</span>';
      }

      echo "<li>
              <div class='dish-left'>
                $icon_html
                <span class='dish-name'>" . htmlspecialchars($dish['name']) . "</span>
              </div>
              <div class='dish-right'>
                <span class='price'>₹" . htmlspecialchars($dish['price']) . "</span>
                <a class='btn-review' href='dish_page.php?dish_id=" . $dish['id'] . "'>Review</a>
              </div>
            </li>";
  }
  if ($current_category !== '') {
      echo "</ul>";
  }
  ?>
</div>

<!-- Footer -->
<footer class="footer">
  &copy; 2025 UniCanteen. All rights reserved. | 
  <a href="/privacy-policy">Privacy Policy</a> | 
  <a href="/terms-of-service">Terms of Service</a>
</footer>

</body>
</html>
