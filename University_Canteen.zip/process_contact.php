<?php
$servername = "localhost:4306";
$username = "Kerlarity";
$password = "@Kerla2121";
$dbname = "canteen_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $conn->real_escape_string(trim($_POST['name']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $subject = $conn->real_escape_string(trim($_POST['subject']));
    $message = $conn->real_escape_string(trim($_POST['message']));

    $sql = "INSERT INTO contact_messages (name, email, subject, message) 
            VALUES ('$name', '$email', '$subject', '$message')";

    if ($conn->query($sql) === TRUE) {
        header("Location: contact.html?success=1");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
} else {
    header("Location: contact.html");
    exit;
}
?>
