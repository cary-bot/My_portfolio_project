<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require 'includes/db.php';  // your existing DB connection, providing $conn

// Prepare and execute query to get user info
$stmt = $conn->prepare("SELECT id, full_name, username, email, registered_at FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    // User not found in DB - log out or redirect to login
    session_destroy();
    header("Location: login.php");
    exit;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Profile</title>
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    body {
      background-color: #fff7f0;
      color: #333;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      padding: 20px;
    }
    .profile-container {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 6px 18px rgba(255, 165, 0, 0.3);
      padding: 40px 50px;
      max-width: 450px;
      width: 100%;
      text-align: center;
    }
    .profile-container h2 {
      color: #ff6600;
      margin-bottom: 30px;
      font-weight: 700;
      font-size: 2.2rem;
      letter-spacing: 1.2px;
      text-transform: uppercase;
      border-bottom: 2px solid #ff6600;
      padding-bottom: 10px;
    }
    .profile-info {
      text-align: left;
    }
    .profile-info p {
      font-size: 1.1rem;
      margin-bottom: 15px;
      color: #444;
      line-height: 1.4;
    }
    .profile-info strong {
      color: #ff6600;
      width: 120px;
      display: inline-block;
      font-weight: 600;
    }
    /* Responsive */
    @media (max-width: 500px) {
      .profile-container {
        padding: 30px 20px;
      }
      .profile-info p {
        font-size: 1rem;
      }
    }
  </style>
</head>
<body>
  <div class="profile-container">
    <h2>Your Profile</h2>
    <div class="profile-info">
      <p><strong>Name:</strong> <?= htmlspecialchars($user['full_name']) ?></p>
      <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
      <p><strong>Registered At:</strong> <?= htmlspecialchars($user['registered_at']) ?></p>
    </div>
  </div>
</body>
</html>
