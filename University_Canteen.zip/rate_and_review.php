<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Rate & Review - University Canteen</title>
  <style>
    body {
      background: #fff8f0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      color: #4b342f;
    }
    header.navbar {
      background: #2c3e50;
      color: #fff;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 2rem;
      position: sticky;
      top: 0;
      z-index: 100;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
      font-family: 'Georgia', serif;
    }
    header.navbar .logo {
      font-size: 1.8rem;
      font-weight: bold;
      letter-spacing: 2px;
    }
    header.navbar nav a {
      color: white;
      text-decoration: none;
      margin-left: 1.5rem;
      font-weight: 600;
      transition: color 0.3s ease;
    }
    header.navbar nav a:hover {
      color: #ffd180;
    }
    h1.page-title {
      font-family: 'Georgia', serif;
      font-size: 2.8rem;
      text-align: center;
      margin: 2rem 0 1rem;
      color: #9c2b00;
      letter-spacing: 1.2px;
    }
    section {
      max-width: 700px;
      margin: 1rem auto 3rem;
      background: #fff3e6;
      padding: 1.5rem 2rem;
      border-radius: 12px;
      box-shadow: 0 6px 14px rgba(156, 43, 0, 0.25);
    }
    section h2 {
      font-family: 'Georgia', serif;
      color: #9c2b00;
      margin-bottom: 1rem;
      border-bottom: 2px solid #9c2b00;
      padding-bottom: 0.5rem;
    }
    ul.dish-list {
      list-style-type: none;
      padding-left: 0;
      margin: 0;
    }
    ul.dish-list li {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.5rem 0;
      border-bottom: 1px solid #e0cbb8;
      font-size: 1.1rem;
      color: #5d3a1a;
    }
    ul.dish-list li:last-child {
      border-bottom: none;
    }
    button.review-btn {
      background-color: #9c2b00;
      color: white;
      border: none;
      padding: 0.4rem 1.2rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
      box-shadow: 0 3px 6px rgba(156, 43, 0, 0.4);
      user-select: none;
    }
    button.review-btn:hover {
      background-color: #b13a00;
      box-shadow: 0 6px 12px rgba(177, 58, 0, 0.6);
    }
    footer.footer {
      text-align: center;
      margin-top: 3rem;
      padding: 1.5rem 0;
      background: #c04e01;
      color: white;
      font-size: 1rem;
      font-family: 'Georgia', serif;
    }
    footer.footer a {
      color: #ffd180;
      margin: 0 0.8rem;
      text-decoration: none;
      font-weight: 600;
    }
    footer.footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <header class="navbar">
    <div class="logo">UniCanteen</div>
    <nav>
      <a href="homepage1.php">Home</a>
      <a href="menu_today.html">Today-Specials</a>
      <a href="regular_menu.html">Regular Menu</a>
      <a href="rate_and_review.php" aria-current="page">Rate & Review</a>
      <a href="contact.html">Contact</a>
    </nav>
  </header>

  <h1 class="page-title">Rate & Review</h1>

  <section>
    <h2>Today's Special Menu</h2>
    <ul class="dish-list">
      <li>
    Spicy Paneer Wrap
    <button class="review-btn" onclick="window.location.href='review.php'">Review</button>
</li>
      <li>
        Aloo Paratha
        <button class="review-btn" type="button">Review</button>
      </li>
      <li>
        Rajma Chawal
        <button class="review-btn" type="button">Review</button>
      </li>
      <li>
        Fruit Salad
        <button class="review-btn" type="button">Review</button>
      </li>
    </ul>
  </section>

  <section>
    <h2> Regular Menu</h2>
    <ul class="dish-list">
      <li>
        Masala Dosa
        <button class="review-btn" type="button">Review</button>
      </li>
       <li>
         Veg Thali
        <button class="review-btn" type="button">Review</button>
      </li>
       <li>
        Pasta
        <button class="review-btn" type="button">Review</button>
      </li>
       <li>
        Veg Sandwich
        <button class="review-btn" type="button">Review</button>
      </li>
       <li>
        French Fries
        <button class="review-btn" type="button">Review</button>
      </li>
      <li>
        Samosa
        <button class="review-btn" type="button">Review</button>
      </li>
      <li>
        Spring Rolls
        <button class="review-btn" type="button">Review</button>
      </li>
      <li>
        Chakli
        <button class="review-btn" type="button">Review</button>
      </li>
      <li>
        Mixed Vegetable Pakora
        <button class="review-btn" type="button">Review</button>
      </li>
    </ul>
  </section>

  <footer class="footer">
    &copy; 2025 UniCanteen. All rights reserved. | 
    <a href="/privacy-policy">Privacy Policy</a> | 
    <a href="/terms-of-service">Terms of Service</a>
  </footer>

</body>
</html>


