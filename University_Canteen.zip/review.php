<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Optionally fetch user's full name if needed on this page:
$user_stmt = $conn->prepare("SELECT full_name FROM users WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user_data = $user_result->fetch_assoc();
$user_full_name = $user_data['full_name'];
$user_stmt->close();

// Handle new review submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['review_text'])) {
    $review_text = htmlspecialchars(trim($_POST['review_text']));
    $stmt = $conn->prepare("INSERT INTO reviews (user_id, review_text) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $review_text);
    $stmt->execute();
    $stmt->close();
}

// Fetch all reviews
$reviews_query = "SELECT users.full_name, reviews.review_text, reviews.created_at
                  FROM reviews
                  JOIN users ON reviews.user_id = users.id
                  ORDER BY reviews.created_at DESC";
$reviews_result = $conn->query($reviews_query);
?>
