<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require 'includes/db.php';

// Fetch user info for pre-filling the form
$stmt = $conn->prepare("SELECT full_name, username, email FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and sanitize input
    $full_name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // Basic validation (you can expand this)
    if (strlen($full_name) < 3) {
        $errors[] = "Full name must be at least 3 characters.";
    }
    if (strlen($username) < 3) {
        $errors[] = "Username must be at least 3 characters.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    if (empty($errors)) {
        // Update DB (use prepared statement)
        $stmt = $conn->prepare("UPDATE users SET full_name = ?, username = ?, email = ? WHERE id = ?");
        $stmt->bind_param("sssi", $full_name, $username, $email, $_SESSION['user_id']);
        if ($stmt->execute()) {
            $success = "Settings updated successfully.";
            // Update $user array to reflect changes on the page
            $user['full_name'] = $full_name;
            $user['username'] = $username;
            $user['email'] = $email;
        } else {
            $errors[] = "Failed to update settings. Please try again.";
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Settings</title>
  <style>
    * {
      margin: 0; padding: 0; box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    body {
      background-color: #fff7f0;
      color: #333;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      padding: 20px;
    }
    .settings-container {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 6px 18px rgba(255, 165, 0, 0.3);
      padding: 40px 50px;
      max-width: 450px;
      width: 100%;
    }
    h2 {
      color: #ff6600;
      margin-bottom: 30px;
      font-weight: 700;
      font-size: 2.2rem;
      letter-spacing: 1.2px;
      text-transform: uppercase;
      border-bottom: 2px solid #ff6600;
      padding-bottom: 10px;
      text-align: center;
    }
    form {
      display: flex;
      flex-direction: column;
    }
    label {
      margin-bottom: 8px;
      font-weight: 600;
      color: #ff6600;
    }
    input[type="text"],
    input[type="email"] {
      padding: 10px;
      margin-bottom: 20px;
      border: 2px solid #ff6600;
      border-radius: 8px;
      font-size: 1rem;
      transition: border-color 0.3s;
    }
    input[type="text"]:focus,
    input[type="email"]:focus {
      border-color: #cc5200;
      outline: none;
    }
    button {
      background-color: #ff6600;
      color: white;
      font-weight: 700;
      font-size: 1.1rem;
      padding: 12px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s;
    }
    button:hover {
      background-color: #cc5200;
    }
    .messages {
      margin-bottom: 20px;
    }
    .messages .error {
      color: #cc0000;
      font-weight: 600;
      margin-bottom: 10px;
    }
    .messages .success {
      color: #228B22;
      font-weight: 600;
      margin-bottom: 10px;
    }
    @media (max-width: 500px) {
      .settings-container {
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>
  <div class="settings-container">
    <h2>Settings</h2>
    <div class="messages">
      <?php if ($errors): ?>
        <?php foreach ($errors as $error): ?>
          <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endforeach; ?>
      <?php endif; ?>
      <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>
    </div>
    <form method="post" action="">
      <label for="full_name">Full Name</label>
      <input type="text" id="full_name" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required />

      <label for="username">Username</label>
      <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required />

      <label for="email">Email</label>
      <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required />

      <button type="submit">Save Changes</button>
    </form>
  </div>
</body>
</html>
