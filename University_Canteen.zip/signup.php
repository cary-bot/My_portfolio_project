<?php
require 'includes/db.php';
require 'includes/functions.php';

$full_name = sanitizeInput($_POST['full_name']);
$username = sanitizeInput($_POST['username']);
$email = sanitizeInput($_POST['email']);
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $full_name, $username, $email, $password);

if ($stmt->execute()) {
   // echo "Signup successful! <a href='index.html'>Login now</a>";
    header('Location: index.html');
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
