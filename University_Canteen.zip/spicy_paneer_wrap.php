<?php
$reviews = file_exists("reviews_spicy_paneer_wrap.txt") ? file("reviews_spicy_paneer_wrap.txt", FILE_IGNORE_NEW_LINES) : [];

$totalRating = 0;
$reviewCount = 0;

foreach ($reviews as $line) {
    list($rating, $comment) = explode("|", $line);
    $totalRating += (int)$rating;
    $reviewCount++;
}

$averageRating = $reviewCount > 0 ? round($totalRating / $reviewCount, 1) : "No ratings yet";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>University Canteen - Spicy Paneer Wrap</title>
  <link rel="stylesheet" href="maindish_styles.css">
</head>
<body>

<div class="container">
  <!-- Image -->
  <div class="image-container">
    <img src="spicy_paneer_wrap.jpg" alt="Spicy Paneer Wrap">
  </div>

  <!-- Product Details -->
  <div class="product-details">
    <div class="breadcrumbs">
      <a href="#">Home</a> > <a href="#">Canteen</a> > Spicy Paneer Wrap
    </div>

    <h1>
      Spicy Paneer Wrap
      <span class="veg-icon" title="Vegetarian"></span>
    </h1>

    <div class="price">₹90</div>

    <div class="rating">
      <strong>Average Rating:</strong>
      <?php if ($averageRating !== "No ratings yet") { ?>
        ★ <?php echo $averageRating; ?> / 5
      <?php } else { ?>
        <span>No ratings yet</span>
      <?php } ?>
    </div>

    <div class="description">
      <h3>Description:</h3>
      <p>A spicy and flavorful wrap with marinated paneer, fresh vegetables, and a tangy sauce, all wrapped in a soft roti. A perfect balance of spice and flavor!</p>
    </div>

    <div class="ingredients">
      <h3>Ingredients:</h3>
      <ul>
        <li>Panner</li>
        <li>Whole Wheat Roti</li>
        <li>Onions, Tomatoes, Lettuce</li>
        <li>Chili Sauce</li>
        <li>Spices & Herbs</li>
        <li>Curd, Salt, Oil</li>
      </ul>
    </div>

    <!-- Review Form -->
    <div class="review-section">
      <h3>Rate & Review</h3>
      <form action="submit_review_spicy_paneer_wrap.php" method="post">
        <label for="rating">Rating (1-5):</label>
        <input type="number" name="rating" id="rating" min="1" max="5" required>
        <label for="review">Review:</label>
        <textarea name="review" id="review" rows="3" placeholder="Share your thoughts..." required></textarea>
        <button type="submit">Submit Review</button>
      </form>

      <div class="reviews-list">
        <h3>Customer Reviews</h3>
        <?php
        if ($reviewCount === 0) {
            echo "<p class='no-reviews'>No reviews yet.</p>";
        } else {
            foreach (array_reverse($reviews) as $r) {
                list($rating, $comment) = explode("|", $r);
                echo "<div class='review-box'>
                        <p><strong>Rating:</strong> $rating/5</p>
                        <p><strong>Comment:</strong> " . htmlspecialchars($comment) . "</p>
                      </div>";
            }
        }
        ?>
      </div>
    </div>
  </div>
</div>

</body>
</html>
