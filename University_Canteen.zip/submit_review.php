<?php
session_start();
require 'includes/db.php';

// Check if user_id is set in session, not user full_name
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Use directly from session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dish_id = isset($_POST['dish_id']) ? (int)$_POST['dish_id'] : 0;
    $rating = isset($_POST['rating']) ? (int)$_POST['rating'] : 0;
    $review_text = isset($_POST['review']) ? trim($_POST['review']) : '';

    if ($dish_id > 0 && $rating >= 1 && $rating <= 5 && !empty($review_text)) {
        // Sanitize review text
        $review_text = htmlspecialchars($review_text, ENT_QUOTES, 'UTF-8');

        $stmt = $conn->prepare("INSERT INTO reviews (user_id, dish_id, rating, review_text) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiis", $user_id, $dish_id, $rating, $review_text);
        $stmt->execute();
        $stmt->close();
    }
}

// Redirect back to the dish page only if $dish_id is valid, else go to a safe page
if (isset($dish_id) && $dish_id > 0) {
    header("Location: dish_page.php?dish_id=" . $dish_id);
} else {
    header("Location: index.php");
}
exit();
