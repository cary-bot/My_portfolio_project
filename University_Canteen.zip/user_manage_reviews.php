<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'includes/db.php';

$user_id = $_SESSION['user_id'];

// Handle delete review
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    // Delete only if review belongs to this user
    $stmt_del = $conn->prepare("DELETE FROM reviews WHERE id = ? AND user_id = ?");
    $stmt_del->bind_param("ii", $delete_id, $user_id);
    $stmt_del->execute();
    $stmt_del->close();
    header("Location: my_reviews.php");
    exit();
}

// Handle update review form submission
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_review'])) {
    $review_id = intval($_POST['review_id']);
    $rating = intval($_POST['rating']);
    $review_text = trim($_POST['review_text']);

    // Validate input
    if ($rating < 1 || $rating > 5) $errors[] = "Rating must be between 1 and 5.";
    if (empty($review_text)) $errors[] = "Review text cannot be empty.";

    if (empty($errors)) {
        // Update only if review belongs to user
        $stmt_upd = $conn->prepare("UPDATE reviews SET rating = ?, review_text = ? WHERE id = ? AND user_id = ?");
        $stmt_upd->bind_param("isii", $rating, $review_text, $review_id, $user_id);
        $stmt_upd->execute();
        $stmt_upd->close();
        header("Location: my_reviews.php");
        exit();
    }
}

// Fetch user's reviews with dish names
$stmt = $conn->prepare("
    SELECT r.id, r.rating, r.review_text, r.created_at, d.name AS dish_name
    FROM reviews r
    JOIN dishes d ON r.dish_id = d.id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>My Reviews</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background: #fff8f0; /* very light orange-ish white */
      color: #663300; /* dark brown-orange for text */
    }
    h1 {
      color: #e65100; /* deep orange */
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
      background: #fff;
      box-shadow: 0 0 5px rgba(230, 126, 34, 0.3); /* soft orange shadow */
    }
    th, td {
      padding: 12px 15px;
      border: 1px solid #f2b179; /* light orange border */
      text-align: left;
      vertical-align: top;
    }
    th {
      background: #ffcc80; /* light orange */
      color: #e65100; /* deep orange */
    }
    tr:hover {
      background: #ffe0b2; /* very light orange */
    }
    button, input[type="submit"] {
      background: #ef6c00; /* vibrant orange */
      color: white;
      border: none;
      padding: 8px 12px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      margin-right: 5px;
    }
    button:hover, input[type="submit"]:hover {
      background: #ffa726; /* lighter orange on hover */
    }
    .delete-btn {
      background: #d84315; /* dark red-orange */
    }
    .delete-btn:hover {
      background: #bf360c; /* deeper red-orange */
    }
    form.edit-form {
      margin: 0;
    }
    textarea, input[type="number"] {
      width: 100%;
      box-sizing: border-box;
      font-size: 14px;
      margin-top: 4px;
      margin-bottom: 8px;
      padding: 6px 8px;
      border-radius: 4px;
      border: 1px solid #f2b179; /* light orange */
    }
    .error {
      color: #b00000;
      font-weight: 600;
      margin-bottom: 15px;
    }
    .actions {
      white-space: nowrap;
      width: 140px;
    }
  </style>
  <script>
    function toggleEdit(id) {
      const viewRow = document.getElementById('view-' + id);
      const editRow = document.getElementById('edit-' + id);
      if (editRow.style.display === 'none') {
        editRow.style.display = 'table-row';
        viewRow.style.display = 'none';
      } else {
        editRow.style.display = 'none';
        viewRow.style.display = 'table-row';
      }
    }
  </script>
</head>
<body>
  <h1>My Reviews</h1>

  <?php if (!empty($errors)): ?>
    <div class="error">
      <?php foreach ($errors as $error): ?>
        <div><?= htmlspecialchars($error) ?></div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <table>
    <thead>
      <tr>
        <th>Dish</th>
        <th>Rating</th>
        <th>Review</th>
        <th>Created At</th>
        <th class="actions">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($result && $result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
          <!-- View Row -->
          <tr id="view-<?= $row['id'] ?>">
            <td><?= htmlspecialchars($row['dish_name']) ?></td>
            <td><?= htmlspecialchars($row['rating']) ?>/5</td>
            <td><?= nl2br(htmlspecialchars($row['review_text'])) ?></td>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
            <td>
              <button onclick="toggleEdit(<?= $row['id'] ?>)">Edit</button>
              <a href="my_reviews.php?delete_id=<?= $row['id'] ?>" class="delete-btn" onclick="return confirm('Delete this review?');">Delete</a>
            </td>
          </tr>

          <!-- Edit Row (hidden by default) -->
          <tr id="edit-<?= $row['id'] ?>" style="display:none; background:#ffe0b2;">
            <form method="POST" class="edit-form" action="my_reviews.php">
              <td>
                <strong><?= htmlspecialchars($row['dish_name']) ?></strong>
              </td>
              <td>
                <input type="number" name="rating" min="1" max="5" value="<?= htmlspecialchars($row['rating']) ?>" required />
              </td>
              <td>
                <textarea name="review_text" required><?= htmlspecialchars($row['review_text']) ?></textarea>
              </td>
              <td>
                <?= htmlspecialchars($row['created_at']) ?>
              </td>
              <td>
                <input type="hidden" name="review_id" value="<?= $row['id'] ?>" />
                <input type="submit" name="edit_review" value="Save" />
                <button type="button" onclick="toggleEdit(<?= $row['id'] ?>)">Cancel</button>
              </td>
            </form>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="5" style="text-align:center;">You have not written any reviews yet.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</body>
</html>
